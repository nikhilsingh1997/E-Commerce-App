import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"; // Importing createAsyncThunk and createSlice from Redux Toolkit
import axios from "axios"; // Importing axios for HTTP requests

// Initial state for the home reducer
const initialState = {
    products: [], // Array to store products
    editedProduct: {}, // Object to store edited product details
    carts: [], // Array to store cart items
    isLoading: true // Flag to indicate loading state
};

// Async thunk to fetch initial state data from the server
export const getInitialStateAsync = createAsyncThunk(
    "getInitialState",
    (arg, thunkAPI) => {
        const state = thunkAPI.getState();
        if (state.homeReducer.products.length === 0) { // Fetch data only if products array is empty
            axios.get("https://my-json-server.typicode.com/nikhilsingh1997/JsonEcommerceServerAPI/products")
                .then((res) => {
                    console.log("response", res.data);
                    thunkAPI.dispatch(actions.setInitialState(res.data)); // Dispatch action to set initial state with fetched data
                });
        }
    }
);

// Redux slice for home reducer
const homeSlice = createSlice({
    name: "home",
    initialState: initialState,
    reducers: {
        // Reducer to set initial state with fetched data
        setInitialState: (state, action) => {
            state.products = action.payload.map((product) => ({ ...product })); // Map fetched data to products array
            state.isLoading = false; // Set loading state to false
            console.log("products", state.products);
        },
        // Reducer to add stars to a product
        addStars: (state, action) => {
            const { stars, productId } = action.payload;
            const index = state.products.findIndex(product => product.id === productId); // Find the index of the product
            if (index !== -1) { // If product exists
                const updatedProduct = { ...state.products[index], stars: stars }; // Update stars for the product
                state.products[productId - 1] = { ...updatedProduct }; // Update product in the products array
            }
        },
        // Reducers to sort products by id, price, and name
        sortById: (state, action) => {
            state.products.sort((a, b) => a.id - b.id);
        },
        sortByPrice: (state, action) => {
            const sortedProducts = [...state.products].sort((a, b) => a.price - b.price);
            state.products = [...sortedProducts];
        },
        sortByName: (state) => {
            state.products.sort((a, b) => {
                const nameA = a.name;
                const nameB = b.name;
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                return 0;
            });
        },
        // Reducer to delete a product
        deleteProduct: (state, action) => {
          state.products =  state.products.filter((product) => product.id !== action.payload);
        },
        // Reducer to handle changes in edited product
        handleInputChanges: (state, action) => {
            state.editedProduct = { ...state.editedProduct, ...action.payload };
            console.log("REDUCER handleInputChanges", state.editedProduct);
            console.log("REDUCER handleInputChanges", action.payload);
        },
        // Reducer to save changes to a product
        handleSaveChanges: (state, action) => {
            console.log("HANDLESAVE :", action.payload)
            const updatedPrdoucts = [...state.products];
            updatedPrdoucts[action.payload] = state.editedProduct;
            state.products = updatedPrdoucts;
            console.log("REDUCER handleSaveChanges editedProduct", state.products[action.payload], state.editedProduct);
        },
        // Reducer to add a product to the cart
        setCart: (state, action) => {
            const productAddedToCart = state.products[action.payload];
            const index = state.carts.findIndex((item) => item.id === action.payload);
            if (index === -1) {
                state.carts.push({ ...productAddedToCart, qty: 1 });
            } else {
                state.carts[index].qty++;
            }
        },
        // Reducer to add a product
        addProduct: (state, action) => {
            state.products.push(action.payload);
        }
    }
});

// Exporting reducer, actions, and selectors
export const homeReducer = homeSlice.reducer;
export const actions = homeSlice.actions;
export const productSelector = (state) => state.homeReducer.products;
export const addStarSelector = (state) => state.homeReducer.stars;
export const editedProductSelector = (state) => state.homeReducer.editedProduct;
export const isLoadingSelector = (state) => state.homeReducer.isLoading;
export const cartsSelector = (state) => state.homeReducer.carts;

// Commented out unused async thunks
