import { createSlice } from "@reduxjs/toolkit";
import { actions } from "./HomeReducer";

const initialState = {
    message : ""
}

const notificationSlice =  createSlice(
    {name : "notification" , 
     initialState : initialState,
     reducers : {
        resetMessage : (state, action)=> {
            state.message = "";
            console.log("RESET MESSAGE");
        }
     },
     extraReducers : (builder) => {
        builder.addCase(actions.addProduct, (state, action)=> {state.message = "The product has been added."});
        builder.addCase(actions.deleteProduct, (state, action)=> {state.message = "The product has been deleted."});
        builder.addCase(actions.handleSaveChanges, (state, action)=> {state.message = "The product has been updated."});
        builder.addCase(actions.setCart, (state, action)=> {state.message = "The product has been added to the cart."});
        builder.addCase(actions.sortByPrice, (state, action)=> {state.message = "The products list have been sorted."})
     }
    });


    export const notificationReducer = notificationSlice.reducer;
    export const messageSelector = (state)=> state.notificationReducer.message;
    // export const {resetMessage} = notificationSlice.actions;
    export const actionsNotifications = notificationSlice.actions;
    