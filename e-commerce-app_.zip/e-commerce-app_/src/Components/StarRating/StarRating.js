import React from 'react'; // Importing React
// import { addStarSelector } from '../../Redux/Reducers/HomeReducer'; // Importing selector for stars from Redux reducer
import { actions } from '../../Redux/Reducers/HomeReducer'; // Importing actions from Redux reducer
import { useDispatch } from 'react-redux'; // Importing useDispatch hook from react-redux
import { useState } from 'react'; // Importing useState hook from React

function StarRating({ productId, stars }) {
    // const stars = useSelector(addStarSelector); // Selecting stars from Redux store state
    const dispatch = useDispatch(); // Getting the dispatch function from useDispatch hook
    // console.log(stars);

    const handleStarClick = (star) => { // Function to handle star click
        // setSelectedStar(star); // Setting the selected star
        dispatch(actions.addStars({ productId, stars: star })); // Dispatching action to add stars
    }

    return (
        <div>
            {[1, 2, 3, 4, 5].map((star, index) => { // Mapping through stars array
                return (
                    <span onClick={() => handleStarClick(star)} // Handling click on star
                        style={{
                            cursor: "pointer", // Setting cursor style
                            color: star <= stars ? "gold" : "grey", // Setting star color based on rating
                            fontSize: "20px" // Setting star font size
                        }} key={index}>
                        {' '} ★ {/* Displaying star symbol */}
                    </span>
                )
            })}
        </div>
    )
}

export default StarRating;
