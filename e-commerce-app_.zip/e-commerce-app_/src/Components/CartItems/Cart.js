import { useSelector } from "react-redux"; // Importing useSelector hook from react-redux for accessing state from Redux store
import { cartsSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selector for carts from Redux reducer
import { useNavigate } from "react-router"; // Importing useNavigate hook from react-router for navigation
import "./Cart.css"; // Importing CSS file for styling

export default function Cart() {
    const carts = useSelector(cartsSelector); // Selecting carts from Redux store state
    let noItems = true; // Initializing a variable to track if there are no items in the cart

    if (carts.length > 0) { // Checking if there are items in the cart
        noItems = false; // Updating noItems to false if there are items in the cart
    }

    const navigate = useNavigate(); // Getting the navigate function from useNavigate hook for navigation
    const totalPrice = carts.reduce((total, currentItem) => total + (currentItem.qty * currentItem.price), 0); // Calculating the total price of items in the cart

    const handleBack = () => { // Function to handle going back to the home page
        navigate('/'); // Navigating back to the home page
    }

    return (
        <div className="outer">
            <h3>Total Cart Price: {totalPrice}</h3> {/* Displaying the total cart price */}
            <button className="back-btn" onClick={handleBack}>Go back</button> {/* Button to go back to the home page */}
            {noItems ? <h2>Ohh..! Your cart is empty. Kindly Add items to the cart</h2> : // Conditional rendering to display a message if the cart is empty
                carts.map((cart, key) => { // Mapping through the items in the cart
                    return (
                        <div className="product-container" key={key}> {/* Container for each product in the cart */}
                            <div className="img">
                                <img src={cart.image} alt={cart.image} /> {/* Displaying the image of the product */}
                            </div>
                            <div className="price-name">
                                <h2>{cart.name}</h2> {/* Displaying the name of the product */}
                                <span>{cart.price}$</span> {/* Displaying the price of the product */}
                            </div>
                            <div className="description">
                                <h2>{cart.description}</h2> {/* Displaying the description of the product */}
                                <span>Quantity: {cart.qty}</span> {/* Displaying the quantity of the product */}
                                <span>&nbsp;&nbsp;&nbsp;</span>
                                <span>Total: {cart.qty * cart.price}</span> {/* Displaying the total price of the product */}
                                <br />
                                <br />
                            </div>
                            <hr />
                        </div>
                    )
                })}
        </div>
    )
}
