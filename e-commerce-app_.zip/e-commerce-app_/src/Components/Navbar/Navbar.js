import { Outlet, useNavigate } from "react-router"; // Importing Outlet and useNavigate from react-router for nested routing
import "./Navbar.css"; // Importing CSS file for styling
import { cartsSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selector for carts from Redux reducer
import { useSelector } from "react-redux"; // Importing useSelector hook from react-redux
import { Link } from "react-router-dom"; // Importing Link component from react-router-dom for navigation

function Navbar() {
    const carts = useSelector(cartsSelector); // Selecting carts from Redux store state
    const navigate = useNavigate(); // Getting the navigate function from useNavigate hook for navigation
    const itemsAddedtoCart = carts.reduce((total, currentItem) => total + currentItem.qty, 0); // Calculating total items added to cart

    const handleCart = () => { // Function to handle navigation to the cart page
        navigate('/cart'); // Navigating to the cart page
    }

    return (
        <>
            <div className="outer-div">
                <div className="app">
                    <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}><h2>E-Commerce App<img src="https://cdn-icons-png.flaticon.com/512/1591/1591111.png" /></h2></Link> {/* Link to home page */}
                    <h3>Product</h3> {/* Placeholder for product link */}
                    <Link to="/addProduct" style={{ textDecoration: 'none', color: 'inherit' }}><h3>Add a product <i class="fa-solid fa-plus"></i></h3></Link> {/* Link to add product page */}
                </div>
                <Link to="/cart"><div className="cart"><img src="https://cdn-icons-png.flaticon.com/128/4290/4290854.png" /> Cart</div></Link> {/* Link to cart page */}
                <span className="cart-items" onClick={handleCart}>{itemsAddedtoCart}</span> {/* Displaying total items added to cart */}
            </div>
            <Outlet /> {/* Outlet for rendering nested routes */}
        </>
    )
}

export default Navbar;
