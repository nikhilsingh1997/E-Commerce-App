import { productSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selector for products from Redux reducer
import { useDispatch, useSelector } from "react-redux"; // Importing useDispatch and useSelector hooks from react-redux
import { useParams } from "react-router"; // Importing useParams hook from react-router for accessing route parameters
import "./ProductDetails.css"; // Importing CSS file for styling
import StarRating from "../StarRating/StarRating"; // Importing StarRating component
import { actions } from "../../Redux/Reducers/HomeReducer"; // Importing actions from Redux reducer
import { actionsNotifications } from "../../Redux/Reducers/notificationreducer"; // Importing actions for notifications from Redux reducer
import { messageSelector } from "../../Redux/Reducers/notificationreducer"; // Importing selector for messages from Redux reducer

export default function ProductDetails() {
    const products = useSelector(productSelector); // Selecting products from Redux store state
    const { id } = useParams(); // Getting the id parameter from URL
    const productId = parseInt(id); // Parsing id to integer
    const productClicked = products[id]; // Getting the product details based on id
    const dispatch = useDispatch(); // Getting the dispatch function from useDispatch hook
    const message = useSelector(messageSelector); // Selecting message from Redux store state

    const handleCartDetails = (productId) => { // Function to handle adding product to cart
        dispatch(actions.setCart(productId)); // Dispatching action to add product to cart
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
    }

    return (
        <div className="prod-det-container" style={{ backgroundColor: "cyan" }}>
            {message && ( // Displaying message if available
                <div class="alert alert-primary" role="alert" style={{ backgroundColor: "orange", color: "black", height: "32px", width: "400px", padding: "5px", fontFamily: "cursive", position: "fixed", marginTop: "-10px", marginLeft: "75vw" }}>
                    {message}
                </div>
            )}
            <div><img src={productClicked.image} style={{ height: "70vh", width: "25vw" }} /></div> {/* Displaying product image */}
            <div style={{ padding: "30px", backgroundColor: "red", height: "62.2vh" }}>
                <h1>{productClicked.description}</h1> {/* Displaying product description */}
                <p style={{ marginTop: "5vh" }}> {/* Placeholder text */}
                    Explore our collection of high-quality products designed to enhance your lifestyle. From stylish accessories to cutting-edge gadgets, we have everything you need to stay ahead in today's fast-paced world. Discover unparalleled comfort, functionality, and style with our carefully curated selection. Elevate your everyday experience with our premium products.
                </p>
                <p style={{ marginTop: "10vh" }}><StarRating productId={id} stars={productClicked.stars} /></p> {/* Displaying StarRating component */}
                <p>{productClicked.price}$</p> {/* Displaying product price */}
                <p> {/* Button to add product to cart */}
                    <button className="prod-det-cart-btn" style={{ padding: "5px", width: "120px", backgroundColor: "orange", border: "none", borderRadius: "4px" }} onClick={() => handleCartDetails(productId)}>Add to Cart</button>
                </p>
            </div>
        </div>
    )
}
