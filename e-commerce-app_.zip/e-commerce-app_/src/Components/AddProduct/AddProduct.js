import "./AddProduct.css"; // Importing CSS file for styling
import { useState } from "react"; // Importing useState hook for managing state in functional components
import { actions } from "../../Redux/Reducers/HomeReducer"; // Importing actions from Redux reducer
import { useSelector, useDispatch } from "react-redux"; // Importing useSelector and useDispatch hooks for accessing and dispatching actions in Redux
import { Link } from "react-router-dom"; // Importing Link component from react-router-dom for navigation
import { useEffect } from "react"; // Importing useEffect hook for side effects in functional components
import { productSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selector for products from Redux reducer
import { actionsNotifications } from "../../Redux/Reducers/notificationreducer"; // Importing actions for notifications from Redux reducer

export default function AddProduct() {
    const products = useSelector(productSelector); // Selecting products from Redux store state
    const [productToAdd, setProductToAdd] = useState({}); // State for storing the product to be added
    const dispatch = useDispatch(); // Getting the dispatch function from useDispatch hook

    const handleAddChange = (e, fieldToAdd) => { // Function to handle changes in input fields
        setProductToAdd({ ...productToAdd, [fieldToAdd]: e.target.value }); // Updating the productToAdd state with the new field value
        console.log("Adding Product Change", { ...productToAdd }); // Logging the updated productToAdd state
    }

    const handleAdd = () => { // Function to handle adding a product
        dispatch(actions.addProduct({ ...productToAdd, id: products.length })); // Dispatching an action to add the product to Redux store state
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
    }

    return (
        <div className="outer-div-add-product">
            <div className="add-product-container">
                <h2>Add a Product</h2>
                <label htmlFor="name">Name</label>
                <input type="text" name="name" placeholder="Enter the product name." value={productToAdd.name} onChange={(e) => handleAddChange(e, "name")} />
                <label htmlFor="description">Description</label>
                <input type="text" name="description" placeholder="Enter the description." value={productToAdd.description} onChange={(e) => handleAddChange(e, "description")} />
                <label htmlFor="price">Price</label>
                <input type="number" name="price" placeholder="Enter the price." value={productToAdd.price} onChange={(e) => handleAddChange(e, "price")} />
                <label htmlFor="rating">Rating</label>
                <input type="number" name="rating" placeholder="Enter the rating." value={productToAdd.stars} onChange={(e) => handleAddChange(e, "stars")} />
                <Link to="/"><button className="add-btn" onClick={handleAdd}>Add</button></Link>
            </div>
        </div>
    )
}
