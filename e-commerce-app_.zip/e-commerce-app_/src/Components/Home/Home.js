import { useEffect, useState } from "react"; // Importing useEffect and useState hooks from React
import { actions } from "../../Redux/Reducers/HomeReducer"; // Importing actions from Redux reducer
import { productSelector, getInitialStateAsync, addStarSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selectors from Redux reducer
import { useSelector, useDispatch } from "react-redux"; // Importing useSelector and useDispatch hooks from react-redux
import "./Home.css"; // Importing CSS file for styling
import StarRating from "../StarRating/StarRating"; // Importing StarRating component
import { messageSelector } from "../../Redux/Reducers/notificationreducer"; // Importing selector for messages from Redux reducer
import { actionsNotifications } from "../../Redux/Reducers/notificationreducer"; // Importing actions for notifications from Redux reducer
import { Link } from "react-router-dom"; // Importing Link component from react-router-dom for navigation
import { isLoadingSelector } from "../../Redux/Reducers/HomeReducer"; // Importing selector for loading state from Redux reducer

function Home() {
    const products = useSelector(productSelector); // Selecting products from Redux store state
    const dispatch = useDispatch(); // Getting the dispatch function from useDispatch hook
    const [editProductId, setEditProductId] = useState(""); // State for tracking the product being edited
    const [productToUpdate, setProductToUpdate] = useState({}); // State for storing the product to be updated
    const [sort, setSort] = useState(""); // State for sorting
    const [sortByPrice, setSortByPrice] = useState(true); // State for sorting by price
    const message = useSelector(messageSelector); // Selecting message from Redux store state
    const isLoading = useSelector(isLoadingSelector); // Selecting loading state from Redux store state

    useEffect(() => { // Effect hook to fetch initial data
        dispatch(getInitialStateAsync());
    }, []);

    const handleSort = (sortArg) => { // Function to handle sorting
        setTimeout(() => toggleSort(), 50); // Delay before toggling sort type
        setSort(sortArg); // Setting the sort type
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
        switch (sortArg) { // Switching based on sort type
            case "price":
                return dispatch(actions.sortByPrice());
            case "name":
                return dispatch(actions.sortByName());
            case "":
                return dispatch(actions.sortById());
            default:
                break;
        }
    }

    const toggleSort = () => { // Function to toggle sorting by price
        setSortByPrice((prevState) => !prevState);
    }

    const handleDelete = (productId) => { // Function to handle deleting a product
        dispatch(actions.deleteProduct(productId)); // Dispatching action to delete product
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
    }

    const handleEdit = (productId) => { // Function to handle editing a product
        setEditProductId(productId); // Setting the product ID being edited
        const product = products.find(product => product.id === productId); // Finding the product to edit
        setProductToUpdate(product); // Setting the product to be updated
        dispatch(actions.handleInputChanges({ ...product })); // Dispatching action to handle input changes
        console.log("handleEdit :", productId);
    }

    const handleCart = (productId) => { // Function to handle adding a product to cart
        dispatch(actions.setCart(productId)); // Dispatching action to add product to cart
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
    }

    const handleInputChanges = (e, fieldBeingChanged) => { // Function to handle changes in input fields
        setProductToUpdate((prevState) => { // Updating the product to be updated
            const editedProduct = {
                ...prevState,
                [fieldBeingChanged]: e.target.value
            };
            dispatch(actions.handleInputChanges(editedProduct)); // Dispatching action to handle input changes
            return editedProduct;
        });
    };

    const handleSaveChanges = (productId) => { // Function to handle saving changes to a product
        console.log("handleSave :", productId);
        dispatch(actions.handleSaveChanges(productId)); // Dispatching action to save changes
        setEditProductId(" "); // Clearing the product ID being edited
        setTimeout(() => dispatch(actionsNotifications.resetMessage()), 2000); // Resetting notification message after 2 seconds
    }


    return (
        <>{ isLoading ? <div style ={{padding: "400px", marginLeft : "400px"}} ><img src = "https://cdn-icons-png.flaticon.com/128/12366/12366724.png" alt = "Loading"/></div> :
            <div className="outer" >
            {message && <div class="alert alert-primary" role="alert" style = {{backgroundColor : "orange", color : "black", height : "32px",width : "400px", padding : "5px", fontFamily : "cursive", position : "fixed", marginTop : "-10px", marginLeft : "75vw"}} >
                         {message}
                     </div> }
            <h3 className="outer-h3" >Check each product page for other buying options. Price and other details may vary based on product size and color.</h3>
                      { sortByPrice ? <button className = "sort" value = "price" onClick = {(e)=> handleSort(e.target.value)} >Sort by price </button> :  <button className = "sort" value = "" onClick = {(e)=> handleSort(e.target.value)} ><img className="sort-img" src ="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXdkCLLohTs7AiVkpfOXJOl3rojyfLMyJx5G0UgKg2zQ&s"/>Sort By Price </button>}
            {products.map((product, index)=> {
                // editProductId === product.id;
                const isEditing  = editProductId === product.id;
                return (
                    <div className="product-container" key={index}>
                        <Link to = {`/productDetails/${product.id}`} style={{ textDecoration: 'none', color: 'inherit' }} >
                        <div className="img">
                            <img src = {product.image} alt = {product.image} />
                        </div>    
                        </Link>
                        {
                            isEditing ? 
                            <div className="edit-div" >
                                <div className="edit-price-name"> 
                                    <input className="edit-name" type = "text" placeholder="Enter the Product Name." value = {productToUpdate.name} onChange={(e)=> handleInputChanges(e, "name")}  />
                                    <input className="edit-price" type = "number" placeholder = "Enter the Product Price." value = {productToUpdate.price} onChange = {(e)=> {handleInputChanges(e, "price")}} />
                                    <input type = "number" placeholder="Enter the Stars" value = {productToUpdate.stars} onChange={(e)=> handleInputChanges(e, "stars")} />
                                    {/* <StarRating className="edit-star" productId = {product.id} stars = {product.stars}/> */}
                                </div>
                                <div className="edit-description" >
                                    <input className="edit-description-input" type = "text" placeholder="Enter the Product Description." value = {productToUpdate.description} onChange = {(e)=> handleInputChanges(e, "description")}/>
                                </div>

                                <button className="edit-btn-cancel" onClick = {()=>setEditProductId("")} >Cancel</button>
                                <button className="edit-btn-save" onClick = {()=>handleSaveChanges(index)} >Save Changes</button>

                            </div> 
                            :<>
                                <div className="price-name"> 
                                    <Link to = {`/productDetails/${product.id}`} style={{ textDecoration: 'none', color: 'inherit' }} ><h2>{product.name}</h2></Link>
                                    <span>{product.price}$</span>
                                    <StarRating productId = {product.id} stars = {product.stars}/>
                                </div>
                                <div className="description" >
                                    <h2>{product.description}
                                    <br/>
                                    <br/>
                                    <span>Explore our collection of high-quality products designed to enhance your lifestyle. From stylish accessories to cutting-edge gadgets, we have everything you need to stay ahead in today's fast-paced world. Discover unparalleled comfort, functionality, and style with our carefully curated selection. Elevate your everyday experience with our premium products.</span></h2>
                                </div>
                                <div className="buttons" >
                                    <button className="edit-btn-cart" onClick={()=> handleCart(product.id)} >Add to Cart</button>
                                    <button className="edit-btn-cancel" onClick={()=>handleDelete(product.id)} >Delete</button>
                                    <button className="edit-btn-save"  onClick={()=> handleEdit(product.id)} >Edit</button>
                                    
                                </div>
                             </>
                        }

                        
                     <hr/>
                    </div>
                )
            })}
        </div>}</>
    )
}

export default Home;