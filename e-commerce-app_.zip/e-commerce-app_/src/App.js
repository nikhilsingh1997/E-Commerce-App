import Navbar from "./Components/Navbar/Navbar";
import Home from "./Components/Home/Home.js";
import Cart from "./Components/CartItems/Cart.js";
import AddProduct from "./Components/AddProduct/AddProduct.js";
import { Provider } from "react-redux";
import { store } from "./store.js";
import {createBrowserRouter, RouterProvider} from "react-router-dom"
import ProductDetails from "./Components/ProductDetails/ProductDetails.js";


function App() {

  const router = createBrowserRouter([
      { path : "/", 
        element : <Navbar/>, 
        children : [
          { index : true, element : <Home/>},
          { path : "/cart", element : <Cart/>},
          { path : "/addProduct", element : <AddProduct/>},
          { path : "/productDetails/:id", element : <ProductDetails/>}
      ], 
      }
  ])

  return (
    <div>
      <Provider store = {store} >
      <RouterProvider router = {router} />
      </Provider>
    </div>
  );
}

export default App;
