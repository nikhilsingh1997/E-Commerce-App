import { configureStore } from "@reduxjs/toolkit";
import { homeReducer } from "./Redux/Reducers/HomeReducer";
import { notificationReducer } from "./Redux/Reducers/notificationreducer";

export const store = configureStore({
    reducer : {
        homeReducer,
        notificationReducer,
    }
})